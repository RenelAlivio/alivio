-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2023 at 08:35 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tables`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_groceries`
--

CREATE TABLE `tbl_groceries` (
  `grocery_id` varchar(255) NOT NULL DEFAULT uuid(),
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_groceries`
--

INSERT INTO `tbl_groceries` (`grocery_id`, `title`, `description`, `user_id`, `created_at`, `updated_at`) VALUES
('3f4d49d0-7d4c-11ee-9121-eca86b70401f', 'seven eleven', 'items from seven eleven', 'ba2597b2-7d20-11ee-97e3-80ce6222b684', '2023-11-07 09:01:33', '2023-11-07 09:01:33'),
('57f39409-7d21-11ee-97e3-80ce6222b684', 'jewelry store', 'items from jewelry store', 'ba2597b2-7d20-11ee-97e3-80ce6222b684', '2023-11-07 03:54:25', '2023-11-07 03:54:25');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_grocery_items`
--

CREATE TABLE `tbl_grocery_items` (
  `item_id` varchar(255) NOT NULL DEFAULT uuid(),
  `name` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `price` varchar(255) NOT NULL,
  `grocery_id` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_grocery_items`
--

INSERT INTO `tbl_grocery_items` (`item_id`, `name`, `quantity`, `price`, `grocery_id`, `created_at`, `updated_at`) VALUES
('176831c4-7d50-11ee-9121-eca86b70401f', 'gold rings', '10', '2000', '57f39409-7d21-11ee-97e3-80ce6222b684', '2023-11-07 09:29:04', '2023-11-07 09:29:04'),
('3fb99dd7-7d4f-11ee-9121-eca86b70401f', 'gold ring', '10', '2000', '57f39409-7d21-11ee-97e3-80ce6222b684', '2023-11-07 09:23:02', '2023-11-07 09:23:02'),
('4a3ffdf9-7d22-11ee-97e3-80ce6222b684', 'goldbracelet', '10', '5000.00', '57f39409-7d21-11ee-97e3-80ce6222b684', '2023-11-07 04:01:12', '2023-11-07 04:01:12'),
('95d04fa6-7d23-11ee-97e3-80ce6222b684', 'gold', '30', '5000.00', '57f39409-7d21-11ee-97e3-80ce6222b684', '2023-11-07 04:10:28', '2023-11-07 04:10:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` varchar(255) NOT NULL DEFAULT uuid(),
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `email`, `password`, `created_at`, `updated_at`) VALUES
('82b8a57b-7d49-11ee-9121-eca86b70401f', 'ermac@gmail.com', '123456789', '2023-11-07 08:41:57', '2023-11-07 08:41:57'),
('ba2597b2-7d20-11ee-97e3-80ce6222b684', 'ermac@gmail.com', '09326886052', '2023-11-07 03:50:01', '2023-11-07 03:50:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_groceries`
--
ALTER TABLE `tbl_groceries`
  ADD PRIMARY KEY (`grocery_id`),
  ADD UNIQUE KEY `grocery_id` (`grocery_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `tbl_grocery_items`
--
ALTER TABLE `tbl_grocery_items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `item_id` (`item_id`),
  ADD KEY `grocery_id` (`grocery_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_groceries`
--
ALTER TABLE `tbl_groceries`
  ADD CONSTRAINT `tbl_groceries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`user_id`);

--
-- Constraints for table `tbl_grocery_items`
--
ALTER TABLE `tbl_grocery_items`
  ADD CONSTRAINT `tbl_grocery_items_ibfk_1` FOREIGN KEY (`grocery_id`) REFERENCES `tbl_groceries` (`grocery_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
