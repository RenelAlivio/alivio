const express = require("express");
const mysql = require("mysql");
const bodyParser = require("body-parser"); // Don't forget to include the body-parser middleware
const app = express();

app.use(bodyParser.json()); // Middleware to parse JSON request bodies

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    database: "midterm_exam"
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err);
        throw err; // Stop the server if the database connection fails
    } else {
        console.log('Database connected successfully');
    }
});

// Handle User Registration POST Request
app.post('/user/register', (req, res) => {
    const { email, password } = req.body; // Assuming you've included bodyParser middleware
    // Perform validation on email and password if needed

    // Check if the email already exists in the database
    const checkEmailQuery = "SELECT * FROM `tbl_users` WHERE `email` = ?";
    db.query(checkEmailQuery, [email], (checkErr, checkResult) => {
        if (checkErr) {
            console.error('Error checking email:', checkErr);
            res.status(500).json({ message: 'Registration failed' });
        } else {
            if (checkResult.length > 0) {
                // Email already exists, return an error
                res.status(400).json({ message: 'Email already exist' });
            } else {
                // Insert user data into the database
                const insertQuery = "INSERT INTO `tbl_users` (`email`, `password`) VALUES (?, ?)";
                db.query(insertQuery, [email, password], (insertErr, result) => {
                    if (insertErr) {
                        console.error('Error registering user:', insertErr);
                        res.status(500).json({ message: 'Registration failed' });
                    } else {
                        res.status(201).json({
                            message: 'User has been created',
                            data: {
                                user_id: result.insertId, // Assuming your user_id is auto-incremented
                            },
                        });
                    }
                });
            }
        }
    });
});


app.post('/user/login', (req, res) => {
    const { email, password } = req.body;

    // Check if the email exists in the database
    const checkEmailQuery = "SELECT `user_id`, `email`, `password` FROM `tbl_users` WHERE email = ?";
    db.query(checkEmailQuery, [email], (err, results) => {
        if (err) {
            console.error('Error during email validation:', err);
            res.status(500).json({ message: 'Login failed' });
        } else {
            if (results.length === 1) {
                // Email exists, proceed with authentication
                const storedPassword = results[0].password;

                if (password === storedPassword) {
                    // Passwords match, user is authenticated
                    res.status(200).json({
                        message: 'User successfully logged in',
                        data: {
                            user_id: results[0].user_id,
                            email: results[0].email,
                        },
                    });
                } else {
                    // Password does not match
                    res.status(401).json({ message: 'Password is not recognized' });
                }
            } else {
                // Email not recognized
                res.status(401).json({ message: 'Email not recognized' });
            }
        }
    });
});

app.get('/grocery/groceries', (req, res) => {
    const userId = req.query.user_id;

    // Check if the user_id is provided
    if (!userId) {
        return res.status(400).json({ message: 'user_id is required' });
    }

    // Use the provided userId in your SQL query
    const selectQuery = "SELECT `title`, `description`, `created_at` FROM `tbl_groceries` WHERE `user_id` = ?";
    db.query(selectQuery, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching groceries:', err);
            res.status(500).json({ message: 'Failed to fetch groceries' });
        } else {
            res.status(200).json({
                message: 'Groceries successfully fetched',
                data: results,
            });
        }
    });
});


app.delete('/grocery/grocery/:grocery_id', (req, res) => {
    const groceryId = req.params.grocery_id;

    // Check if the grocery_id is provided
    if (!groceryId) {
        return res.status(400).json({ message: 'grocery_id is required' });
    }

    // Delete the grocery item from the database
    const deleteQuery = "DELETE FROM `tbl_groceries` WHERE `grocery_id` = ?";
    db.query(deleteQuery, [groceryId], (err, result) => {
        if (err) {
            console.error('Error deleting grocery item:', err);
            res.status(500).json({ message: 'Failed to delete grocery item' });
        } else {
            if (result.affectedRows > 0) {
                // Grocery item successfully deleted
                res.status(200).json({ message: 'Grocery successfully deleted' });
            } else {
                // No grocery item found with the provided ID
                res.status(404).json({ message: 'Grocery item not found' });
            }
        }
    });
});

app.post('/grocery/grocery', (req, res) => {
    const { title, description } = req.body;
    const userId = req.body.user_id; // Assuming user_id is provided in the request body

    // Check if required fields are provided in the payload
    if (!title || !description || !userId) {
        return res.status(400).json({ message: 'Title, description, and user_id are required' });
    }

    // Insert the grocery item into the database
    const insertQuery = "INSERT INTO `tbl_groceries` (`title`, `description`, `user_id`) VALUES (?, ?, ?)";
    db.query(insertQuery, [title, description, userId], (err, result) => {
        if (err) {
            console.error('Error creating grocery item:', err);
            res.status(500).json({ message: 'Failed to create grocery item' });
        } else {
            res.status(201).json({
                message: 'Grocery item has been created',
                data: {
                    grocery_id: result.insertId,
                },
            });
        }
    });
});
app.get('/grocery/grocery_items', (req, res) => {
    const groceryId = req.query.grocery_id;

    // Check if the grocery_id is provided in the query parameters
    if (!groceryId) {
        return res.status(400).json({ message: 'grocery_id is required in query parameters' });
    }

    // Fetch grocery items associated with the specified grocery list
    const selectQuery = "SELECT `name`, `quantity`, `price` FROM `tbl_grocery_items` WHERE `grocery_id` = ?";
    db.query(selectQuery, [groceryId], (err, results) => {
        if (err) {
            console.error('Error fetching grocery items:', err);
            res.status(500).json({ message: 'Failed to fetch grocery items' });
        } else {
            if (results.length === 0) {
                // Check if no results were found for the provided grocery_id
                res.status(404).json({ message: 'No grocery items found for the provided grocery_id' });
            } else {
                res.status(200).json({
                    message: 'Grocery items successfully retrieved',
                    data: results,
                });
            }
        }
    });
});

app.patch('/grocery/grocery_item/:item_id', (req, res) => {
    const itemId = req.params.item_id;
    const { name, qty, price } = req.body;

    // Check if the item_id is provided in the route parameter
    if (!itemId) {
        return res.status(400).json({ message: 'item_id is required in the route parameter' });
    }

    // Construct the UPDATE query to update the grocery item
    const updateQuery = "UPDATE `tbl_grocery_items` SET `name` = ?, `quantity` = ?, `price` = ? WHERE `item_id` = ?";

    // Execute the query with the provided data
    db.query(updateQuery, [name, qty, price, itemId], (err, result) => {
        if (err) {
            console.error('Error updating grocery item:', err);
            res.status(500).json({ message: 'Failed to update grocery item' });
        } else {
            if (result.affectedRows > 0) {
                res.status(200).json({ message: 'Grocery item details successfully updated' });
            } else {
                res.status(404).json({ message: 'Grocery item is not exist' });
            }
        }
    });
});

app.delete('/grocery/grocery_item/:item_id', (req, res) => {
    const itemId = req.params.item_id;

    // Check if the item_id is provided in the route parameter
    if (!itemId) {
        return res.status(400).json({ message: 'item_id is required in the route parameter' });
    }

    // Construct the DELETE query to delete the grocery item
    const deleteQuery = "DELETE FROM `tbl_grocery_items` WHERE `item_id` = ?";

    // Execute the query to delete the grocery item
    db.query(deleteQuery, [itemId], (err, result) => {
        if (err) {
            console.error('Error deleting grocery item:', err);
            res.status(500).json({ message: 'Failed to delete grocery item' });
        } else {
            if (result.affectedRows > 0) {
                res.status(200).json({ message: 'Grocery item successfully deleted' });
            } else {
                res.status(404).json({ message: 'Grocery item not found' });
            }
        }
    });
});

app.post('/grocery/grocery_item', (req, res) => {
    const { name, qty, price, grocery_id } = req.body;

    // Check if the required fields are provided in the request body
    if (!name || !qty || !price || !grocery_id) {
        return res.status(400).json({ message: 'Name, Qty, Price, and grocery_id are required in the request body' });
    }

    // Check if the name already exists in the database
    const checkNameQuery = "SELECT * FROM `tbl_grocery_items` WHERE `name` = ? AND `grocery_id` = ?";
    db.query(checkNameQuery, [name, grocery_id], (checkErr, checkResult) => {
        if (checkErr) {
            console.error('Error checking grocery item name:', checkErr);
            res.status(500).json({ message: 'Failed to check grocery item name' });
        } else {
            if (checkResult.length > 0) {
                res.status(400).json({ message: 'Grocery item with the same name already exists' });
            } else {
                // Grocery item name is unique, proceed to insert
                const insertQuery = "INSERT INTO `tbl_grocery_items` (`name`, `quantity`, `price`, `grocery_id`) VALUES (?, ?, ?, ?)";
                db.query(insertQuery, [name, qty, price, grocery_id], (err, result) => {
                    if (err) {
                        console.error('Error adding grocery item:', err);
                        res.status(500).json({ message: 'Failed to add grocery item' });
                    } else {
                        const item_id = result.insertId; // Get the inserted item's ID
                        res.status(201).json({
                            title: 'created',
                            status: 201,
                            message: 'Grocery item successfully added',
                            data: {
                                item_id: item_id,
                            },
                        });
                    }
                });
            }
        }
    });
});




app.listen(5000, () => {
    console.log('Server is running on port 5000');
});
